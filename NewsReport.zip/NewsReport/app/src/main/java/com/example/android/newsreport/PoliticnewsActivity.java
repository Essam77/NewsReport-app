
package com.example.android.newsreport;

import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PoliticnewsActivity extends AppCompatActivity
        implements LoaderCallbacks<List<Politicnews>>{

    private static final String LOG_TAG = PoliticnewsActivity.class.getName();

    private static final String USGS_REQUEST_URL =
            "http://content.guardianapis.com/search?show-tags=contributor&api-key=test";
     private static final int PoliticNews_LOADER_ID = 1;

    private PoliticnewsAdapter mAdapter;

    private TextView mEmptyStateTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.politicnews_activity);

        ListView poloticnewsListView = (ListView) findViewById(R.id.list);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        poloticnewsListView.setEmptyView(mEmptyStateTextView);

        mAdapter = new PoliticnewsAdapter(this, new ArrayList<Politicnews>());

        poloticnewsListView.setAdapter(mAdapter);

        poloticnewsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Politicnews currentPoliticnews = mAdapter.getItem(position);
                Uri politicnewUri = Uri.parse(currentPoliticnews.getUrl());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, politicnewUri);
                startActivity(websiteIntent);
            }
        });

        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
        LoaderManager loaderManager = getLoaderManager();

        loaderManager.initLoader(PoliticNews_LOADER_ID, null, this);}
       else{
            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);
            mEmptyStateTextView.setText(R.string.no_internet_connection);
        }

    }

    @Override
    public Loader<List<Politicnews>> onCreateLoader(int i, Bundle bundle) {
        return new PoliticnewsLoader(this, USGS_REQUEST_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<Politicnews>> loader, List<Politicnews> politicnews) {

        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        mEmptyStateTextView.setText(R.string.no_earthquakes);
        mAdapter.clear();

        if (politicnews != null && !politicnews.isEmpty()) {
            mAdapter.addAll(politicnews);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Politicnews>> loader) {
        mAdapter.clear();
    }
}
