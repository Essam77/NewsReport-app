package com.example.android.newsreport;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import java.util.List;

public class PoliticnewsLoader extends AsyncTaskLoader<List<Politicnews>> {

    private static final String LOG_TAG = PoliticnewsLoader.class.getName();
    private String mUrl;

    public PoliticnewsLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }
    @Override
    protected void onStartLoading() {
        Log.i(LOG_TAG,"Test:calling onStartLoading");
        forceLoad();
    }
    @Override
    public List<Politicnews> loadInBackground() {
        Log.i(LOG_TAG,"Test:calling loadInBackground");
        if (mUrl == null) {
            return null;
        }
        List<Politicnews> politicnews = QueryUtils.fetchPoliticnewsData(mUrl);
        return politicnews;
    }
}
