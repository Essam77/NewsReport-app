package com.example.android.newsreport;


public class Politicnews {
    private String mSectionId;
    private String mWebTitle;
    private String mPublishDate;
    private String mUrl;
    private String mAuther;

    public Politicnews(String SectionId, String WebTitle, String PublishDate, String url, String Auther) {
        mSectionId = SectionId;
        mWebTitle = WebTitle;
        mPublishDate = PublishDate;
        mUrl = url;
        mAuther=Auther;
    }

   public String getSectionId() { return mSectionId;  }
   public String getWebTitle() {
        return mWebTitle;
    }
   public String getPublishDate() {
        return mPublishDate;
    }
   public String getUrl() {  return mUrl; }
   public String getAuther() { return mAuther; }
}
