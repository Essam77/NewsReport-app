package com.example.android.newsreport;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class PoliticnewsAdapter extends ArrayAdapter<Politicnews> {


    private static final String LOCATION_SEPARATOR = " of ";

       public PoliticnewsAdapter(Context context, List<Politicnews> politicnews) {
        super(context, 0, politicnews);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.politicnews_list_item, parent, false);
        }
        Politicnews currentPoliticnews = getItem(position);

        TextView SectionIdView = (TextView) listItemView.findViewById(R.id.SectionId);
        SectionIdView.setText(currentPoliticnews.getSectionId());

        GradientDrawable sectionIdCircle = (GradientDrawable) SectionIdView.getBackground();
        int sectionColor = getMagnitudeColor(currentPoliticnews.getSectionId());
        sectionIdCircle.setColor(sectionColor);

        TextView AutherView = (TextView) listItemView.findViewById(R.id.WebTitle);
        AutherView.setText(currentPoliticnews.getAuther());

        TextView WebTitleView = (TextView) listItemView.findViewById(R.id.WebAuther);
        WebTitleView.setText(currentPoliticnews.getWebTitle());

     TextView dateView = (TextView) listItemView.findViewById(R.id.date);
     dateView.setText(currentPoliticnews.getPublishDate());

        return listItemView;
    }

    private int getMagnitudeColor(String SectionId) {
        int SectionIdColorResourceId;
        String SectionIdFloor = SectionId;
        switch (SectionIdFloor) {
            case "books":
                SectionIdColorResourceId = R.color.Color1;
                break;
            case "australia-news":
                SectionIdColorResourceId = R.color.color2;
                break;
            case "sport":
                SectionIdColorResourceId = R.color.color2;
                break;
            case "article":
                SectionIdColorResourceId = R.color.color4;
                break;
            case "music":
                SectionIdColorResourceId = R.color.color4;
                break;
            case "environment":
                SectionIdColorResourceId = R.color.color6;
                break;
            case "politics":
                SectionIdColorResourceId = R.color.color8;
                break;
            case "world":
                SectionIdColorResourceId = R.color.color9;
                break;
            default:
                SectionIdColorResourceId = R.color.color10;
                break;
        }

        return ContextCompat.getColor(getContext(), SectionIdColorResourceId);
    }
}
